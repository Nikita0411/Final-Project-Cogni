package com.Icommands;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;

import com.beans.*;

public interface IAdmin {

	
	String inscmd="insert into admindata values(?,?,?,?,?,?,?,?,?)";
	String getUserName="Select * from admindata where userid=?";
	String getUserN="Select * from userdata where email=?";
	String getAccNo= "Select Account_Number from userdata";
	
	String logincmd="Select userid,password from admindata where userid=? and password=?";
	String loginUser="Select email,password from userdata where email=? and password=?";
	
	String selectdefaulter="select Default_Status,Borrower_Name,Borrower_Rating,Accrual_Status,Account_Number,Days_Past_Due from defaulter where Default_Status=? order by Days_Past_Due desc";
	String autodefaulter="Select Default_Status,Borrower_Name,Borrower_Rating,Accrual_Status,Account_Number,Days_Past_Due from defaulter where Borrower_Rating>=8 and Accrual_Status in (2,3,4,5) order by Days_Past_Due desc";
	String manualdefaulter="Select Default_Status,Borrower_Name,Borrower_Rating,Accrual_Status,Account_Number,Days_Past_Due from defaulter where Borrower_Rating between 5 and 7 and Accrual_Status in (1,6,7) and Days_Past_Due>=90 order by Days_Past_Due desc";
	String DPD6month="Select Default_Status,Borrower_Name,Borrower_Rating,Accrual_Status,Account_Number,Days_Past_Due from defaulter where Days_Past_Due>=180";
	
	
	String insertRedefaulter="insert into Redefaulter values(?,?,?,?,?,?)";
	String selectRedefaulter="select Default_Status,Borrower_Name,Borrower_Rating,Accrual_Status,Account_Number,Days_Past_Due from Redefaulter where Default_Status=?";
	
	String deleteDefaulter="delete from defaulter where Account_Number=?";
	String deleteRedefaulter="delete from Redefaulter where Account_Number=?";
	
	String insertdefaulter="insert into defaulter values(?,?,?,?,?,?)";
	String updatedefaulter="Update defaulter set Default_Status=?,Borrower_Rating=?,Accrual_Status=?,Days_Past_Due=? where Account_Number=?";
	
	String updateDPD ="Update redefaulter set Days_Past_Due=? where Account_Number=?";
	
	String insertUser="insert into UserData(First_Name,Last_Name,Contact_Number,Account_Number,Email,Password) values(?,?,?,?,?,?)";
	
	String sendReminder="Update UserData set Reminder=? where Account_Number=?";
	
	String receiveReminder="Select * from Reminder where Account_Number=?";
	
	String changeUPass="Update UserData set password=? where email=?";
	String changeAPass="Update AdminData set password=? where userid=?";
	
	String selectUser="select First_Name, Last_Name, Account_Number, Reminder from UserData where Reminder is not Null";
	
	String insertLoan="insert into LoanData(Account_Number,Loan_Amount,Loan_Date,Duration,Last_Date) values(?,?,?,?,?)";
	
	String laonamt="select Loan_Amount from loandata where Account_Number=?";
	
	String Loandata="Select Pending_Amount,Loan_Amount,Loan_Date,Duration,Last_Date from LoanData where Account_Number=?";
	
	String payment="Update LoanData set Pending_Amount=?, Paid=? where Account_Number=?";
	
	String transaction="insert into Transaction values(?,?,?,?,?)";
	
	String listAllTransactions="select Account_Number,Loan_Amount,Paid,Pending_Amount,TDate from Transaction where Account_Number=?";
	
	String insertRem="insert into reminder values(?,?,?)";
	
	
	
}
