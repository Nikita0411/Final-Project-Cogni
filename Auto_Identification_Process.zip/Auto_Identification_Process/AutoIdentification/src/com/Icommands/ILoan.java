package com.Icommands;

import java.math.BigDecimal;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import com.beans.*;
import com.beans.Transaction;

public interface ILoan {
	
	public int addAdmin(Admin ad) throws SQLException;
	public int addDefaulter(Defaulter d) throws SQLException;
	public int addReDefaulter(ReDefaulter d) throws SQLException;
	public int addUserData(UserData ud) throws SQLException;
	
	public int deleteDefaulter(BigDecimal acno) throws SQLException;
	public int deleteReDefaulter(BigDecimal acno) throws SQLException;
	
	public boolean getAdminCred(String uname,String psw) throws SQLException;
	public boolean getUserCred(String uname,String psw) throws SQLException;
	public ArrayList<BigDecimal> getAccNo() throws SQLException;
	
	public int changeUP(String uname,String psw) throws SQLException;
	public int changeAP(String uname,String psw) throws SQLException;
	
	public Admin getUname(String userid) throws SQLException;
	public UserData getUserName(String email) throws SQLException;
	
	public ArrayList<Defaulter> listAllDefaulters() throws SQLException;
	
	public ArrayList<ReDefaulter> listAllReDefaulters() throws SQLException;
	
	public ArrayList<Defaulter> listAutoDefaulters() throws SQLException;
	
	public ArrayList<Defaulter> listManualDefaulters() throws SQLException;
	
	public ArrayList<Defaulter> listDPD6months() throws SQLException;
	
	public int updateDefaulter(Defaulter d) throws SQLException;
	public int updateDPD(BigDecimal acno,long dpd) throws SQLException;
	
	
	public int sendReminder(String rem,BigDecimal acno) throws SQLException;
	public ArrayList<Reminder> receiveReminder(BigDecimal acno) throws SQLException;
	
	public ArrayList<UserData> listUserData() throws SQLException;
	
	public int addLoan(Loan l) throws SQLException;
	
	public Loan getLoanData(BigDecimal acno) throws SQLException, ParseException;
	
	public int payLoan(Loan l) throws SQLException;
	
	public int addTransaction(Transaction t) throws SQLException;
	
	public ArrayList<Transaction> listAllTransactions(BigDecimal acno) throws SQLException, ParseException;
	
	public int addReminder(Reminder r) throws SQLException;
	
}
