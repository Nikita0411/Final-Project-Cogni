package com.beans;

import java.io.Serializable;

public class Admin implements Serializable
{



String First_Name;
String Last_Name;
int  Age;
String Gender;
//int Contact_no;
String Contact_no;
String City;
String State;
String UserId;
String Password;

public Admin() {
	super();
}

public Admin(String first_Name, String last_Name, int age, String gender,/*int contact_no,*/String contact_no,
		String city,String state, String userId, String password) {
	super();
	First_Name = first_Name;
	Last_Name = last_Name;
	Age = age;
	Gender=gender;
	Contact_no = contact_no;
	City = city;
	State=state;
	UserId = userId;
	Password = password;
}
public String getGender() {
	return Gender;
}

public void setGender(String gender) {
	Gender = gender;
}

public String getFirst_Name() {
	return First_Name;
}
public void setFirst_Name(String first_Name) {
	First_Name = first_Name;
}
public String getLast_Name() {
	return Last_Name;
}
public void setLast_Name(String last_Name) {
	Last_Name = last_Name;
}
public int getAge() {
	return Age;
}
public void setAge(int age) {
	Age = age;
}
/*public int getContact_no() {
	return Contact_no;
}
public void setContact_no(int contact_no) {
	Contact_no = contact_no;
}*/

public String getContact_no() {
	return Contact_no;
}
public void setContact_no(String contact_no) {
	Contact_no = contact_no;
}
	
	
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getUserId() {
	return UserId;
}
public void setUserId(String userId) {
	UserId = userId;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}

public String getState() {
	return State;
}

public void setState(String state) {
	State = state;
}

@Override
public String toString() {
	return "Admin [First_Name=" + First_Name + ", Last_Name=" + Last_Name + ", Age=" + Age + ", Gender=" + Gender
			+ ", Contact_no=" + Contact_no + ", City=" + City + ", State=" + State + ", UserId=" + UserId
			+ ", Password=" + Password + "]";
}

}
