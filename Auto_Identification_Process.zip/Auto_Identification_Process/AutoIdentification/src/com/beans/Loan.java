package com.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Loan implements Serializable
{

	BigDecimal acno;
	long amount;
	Date loanDate;
	long duration;
	Date lastDate;
	long PaidAmt;
	long pendingAmt;
	
	public Loan() {
		super();
	}

	public Loan(BigDecimal acno, long amount, Date loanDate, long duration, Date lastDate) {
		super();
		this.acno = acno;
		this.amount = amount;
		this.loanDate = loanDate;
		this.duration = duration;
		this.lastDate = lastDate;
	}

	public Loan(BigDecimal acno,long pendingAmt, long amount, Date loanDate,long duration, Date lastDate) {
		super();
		this.acno = acno;
		this.pendingAmt=pendingAmt;
		this.amount = amount;
		this.loanDate = loanDate;
		this.duration = duration;
		this.lastDate = lastDate;
	}
	

	public BigDecimal getAcno() {
		return acno;
	}

	public void setAcno(BigDecimal acno) {
		this.acno = acno;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public Date getLoanDate() {
		return loanDate;
	}

	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public Date getLastDate() {
		return lastDate;
	}

	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}

	public long getPaidAmt() {
		return PaidAmt;
	}

	public void setPaidAmt(long paidAmt) {
		PaidAmt = paidAmt;
	}

	public long getPendingAmt() {
		return pendingAmt;
	}

	public void setPendingAmt(long pendingAmt) {
		this.pendingAmt = pendingAmt;
	}

	@Override
	public String toString() {
		return "Loan [acno=" + acno + ", amount=" + amount + ", loanDate=" + loanDate + ", duration=" + duration
				+ ", lastDate=" + lastDate + ", PaidAmt=" + PaidAmt + ", pendingAmt=" + pendingAmt + "]";
	}
	
}
