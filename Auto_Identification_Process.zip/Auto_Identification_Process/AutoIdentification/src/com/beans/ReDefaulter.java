package com.beans;

import java.io.Serializable;
import java.math.BigDecimal;

public class ReDefaulter implements Serializable
{
	String defaultStatus;
	String borrowerName;
	String borrowerRating;
	String acuralStatus;
//	long   accountNumber;
	BigDecimal  accountNumber;
	String daysPastDue;
	//String Comments;
	
	public ReDefaulter() {
		
	}

	public ReDefaulter(String defaultStatus, String borrowerName, String borrowerRating, String accountStatus,
			BigDecimal accountNumber, String daysPastDue) {
		super();
		this.defaultStatus = defaultStatus;
		this.borrowerName = borrowerName;
		this.borrowerRating = borrowerRating;
		this.acuralStatus = accountStatus;
		this.accountNumber = accountNumber;
		this.daysPastDue = daysPastDue;
	}

	public String getDefaultStatus() {
		return defaultStatus;
	}

	public void setDefaultStatus(String defaultStatus) {
		this.defaultStatus = defaultStatus;
	}

	public String getBorrowerName() {
		return borrowerName;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public String getBorrowerRating() {
		return borrowerRating;
	}

	public void setBorrowerRating(String borrowerRating) {
		this.borrowerRating = borrowerRating;
	}

	public String getAcuralStatus() {
		return acuralStatus;
	}

	public void setAcuralStatus(String accountStatus) {
		this.acuralStatus = accountStatus;
	}

	public BigDecimal getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(BigDecimal accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDaysPastDue() {
		return daysPastDue;
	}

	public void setDaysPastDue(String daysPastDue) {
		this.daysPastDue = daysPastDue;
	}
	
	
	/*public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}	*/
	
}
