package com.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Reminder implements Serializable
{

	BigDecimal acno;
	Date remDate;
	String rem;
	
	
	public Reminder() {
		super();
	}

	public Reminder( String rem) {
		super();
		this.rem = rem;
	}

	public Reminder(BigDecimal acno,  Date remDate,String rem) {
		super();
		this.acno = acno;
		this.remDate=remDate;
		this.rem = rem;
	}



	public BigDecimal getAcno() {
		return acno;
	}


	public void setAcno(BigDecimal acno) {
		this.acno = acno;
	}


	public String getRem() {
		return rem;
	}


	public void setRem(String rem) {
		this.rem = rem;
	}

	

	public Date getRemDate() {
		return remDate;
	}

	public void setRemDate(Date remDate) {
		this.remDate = remDate;
	}

	@Override
	public String toString() {
		return "Reminder [acno=" + acno + ", remDate=" + remDate + ", rem=" + rem + "]";
	}

	
	
	
}
