package com.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Transaction implements Serializable
{
	BigDecimal Account_Number;
	long Loan_Amount ;
	long Paid ;
	long Pending_Amount ;
	Date Date;
	
	
	
	public Transaction(BigDecimal account_Number, long loan_Amount, long paid, long pending_Amount, Date date) {
		super();
		Account_Number = account_Number;
		Loan_Amount = loan_Amount;
		Paid = paid;
		Pending_Amount = pending_Amount;
		Date=date;
	}



	public Transaction() {
		
	}



	public BigDecimal getAccount_Number() {
		return Account_Number;
	}




	public void setAccount_Number(BigDecimal account_Number) {
		Account_Number = account_Number;
	}




	public long getLoan_Amount() {
		return Loan_Amount;
	}




	public void setLoan_Amount(long loan_Amount) {
		Loan_Amount = loan_Amount;
	}




	public long getPaid() {
		return Paid;
	}




	public void setPaid(long paid) {
		Paid = paid;
	}




	public long getPending_Amount() {
		return Pending_Amount;
	}




	public void setPending_Amount(long pending_Amount) {
		Pending_Amount = pending_Amount;
	}



	
	public Date getDate() {
		return Date;
	}



	public void setDate(Date date) {
		Date = date;
	}



	@Override
	public String toString() {
		return "Transaction [Account_Number=" + Account_Number + ", Loan_Amount=" + Loan_Amount + ", Paid=" + Paid
				+ ", Pending_Amount=" + Pending_Amount + ", Date=" + Date + "]";
	}




	
	
}
