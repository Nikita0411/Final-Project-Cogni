package com.beans;

import java.io.Serializable;
import java.math.BigDecimal;

public class UserData implements Serializable
{

	String fname;
	String lname;
	long contact;
	BigDecimal accno;
	String email;
	String password;
	String reminder;
	
	public UserData() {
		super();
	}
	
	public UserData(String fname,String lname, long contact,  BigDecimal accno,String email, String password) {
		super();
		this.fname = fname;
		this.lname=lname;
		this.contact = contact;
		this.email = email;
		this.password = password;
		this.accno = accno;
	//	this.reminder=reminder;
	}
	
	public UserData(String fname,String lname, BigDecimal accno, String reminder) {
		super();
		this.fname = fname;
		this.lname=lname;
		//this.contact = contact;
		//this.email = email;
		//this.password = password;
		this.accno = accno;
		this.reminder=reminder;
	}
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public BigDecimal getAccno() {
		return accno;
	}
	public void setAccno(BigDecimal accno) {
		this.accno = accno;
	}

	public String getReminder() {
		return reminder;
	}

	public void setReminder(String reminder) {
		this.reminder = reminder;
	}

	@Override
	public String toString() {
		return "UserData [fname=" + fname + ", lname=" + lname + ", contact=" + contact + ", accno=" + accno
				+ ", email=" + email + ", password=" + password + ", reminder=" + reminder + "]";
	}
	
	
	
}
