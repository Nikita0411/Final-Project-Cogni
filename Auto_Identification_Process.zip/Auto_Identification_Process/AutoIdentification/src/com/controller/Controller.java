package com.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beans.Admin;
import com.beans.Defaulter;
import com.beans.Loan;
import com.beans.ReDefaulter;
import com.beans.Reminder;
import com.beans.Transaction;
import com.beans.UserData;
import com.services.DbService;

/**
 * Servlet implementation class Controller
 */
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Controller() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//ServletContext sc = getServletContext();
		//sc.setAttribute("scuname", "sneha");
		
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		HttpSession hsn=request.getSession();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		
		DbService ds=new DbService();
		String target="";
		String act=request.getParameter("action");
		
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		
//Login Controller..........	
	
		if(act.equals("Login"))
		{
			try {

				String userid=request.getParameter("uname");
				String password=request.getParameter("psw");
				
				hsn.setAttribute("Userid", userid);
				
				Admin ad=ds.getUname(userid);
				UserData ud=ds.getUserName(userid);
				
				boolean flag=ds.getAdminCred(userid, password);
				boolean flag1=ds.getUserCred(userid, password);
				if(flag)
				{	
					hsn.setAttribute("username", ad.getFirst_Name());
					hsn.setAttribute("AdminObject", ad);
					target="/jsp/home.jsp";
				}
				else if(flag1)
				{
					hsn.setAttribute("username", ud.getFname());
					hsn.setAttribute("UserObject", ud);
					hsn.setAttribute("accountofuser", ud.getAccno());
					target="/jsp/UserHome.jsp";
				}
				 else
		         {
				target="/jsp/Unsuccessful.jsp";
		            }
				
			} 
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
		
//Registration controller.........		
		if(act.equals("Register"))
		{
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gen=request.getParameter("gender");
		//int contact=Integer.parseInt(request.getParameter("contact"));
		String contact=request.getParameter("contact");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String uname=request.getParameter("uid");
		
	//	hsn.setAttribute("uid", uname);
		String pwd=request.getParameter("pwd");
		
		
		
		Admin ad=new Admin(fname, lname, age, gen, contact, city, state, uname, pwd);
		try {
			
			int x=ds.addAdmin(ad);
			//System.out.println(" successfully");
			if(x>0)
			{
				//System.out.println("Regiterd successfully");
				
				target="jsp/UserRegistered.jsp";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/			
		//Display all Defaulter list controller........
	 if(act.equals("Defaulter"))
		{
			//System.out.println("All defaulter");
			try {
				ArrayList<Defaulter> al=ds.listAllDefaulters();
				hsn.setAttribute("defaulterlist", al);
				target="jsp/Defaulters.jsp";
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
	 //Display Auto Defaulter list controller........
		 if(act.equals("ReDefaulter"))
			{
				//System.out.println("Redefaulter");
				try {
					ArrayList<ReDefaulter> al=ds.listAllReDefaulters();
					hsn.setAttribute("Redefaulterlist", al);
					target="jsp/Redefaulter.jsp";
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
	//Display Auto Defaulter list controller........
	 if(act.equals("AutoDefaulter"))
		{
			//System.out.println("Auto defaulter");
			try {
				ArrayList<Defaulter> al=ds.listAutoDefaulters();
				hsn.setAttribute("autodefaulterlist", al);
				target="jsp/AutoDefaulter.jsp";
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
	//Display Manual Defaulter list controller........
		 if(act.equals("ManualDefaulter"))
			{
				//System.out.println("Manual defaulter");
				try {
					ArrayList<Defaulter> al=ds.listManualDefaulters();
					hsn.setAttribute("manualdefaulterlist", al);
					target="jsp/ManualDefaulter.jsp";
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
		//Update Defaulter table........ 
		 
	 if(act.equals("Update"))
	 {
		 //System.out.println("Action Update");
		 String defaultstatus=request.getParameter("defaultstatus");
		 String borrowername=request.getParameter("borrowername");
		 String borrowerrating=request.getParameter("borrowerrating");
		 String accrualstatus=request.getParameter("accrualstatus");
		 String ac=request.getParameter("acnum");
		 BigDecimal acno=new BigDecimal(ac);
		 String dayspastdue=request.getParameter("dayspastdue");
		 
	//	 hsn.setAttribute("sendremacno", acno);
		 try
		 {
			 Defaulter d=new Defaulter(defaultstatus, borrowername, borrowerrating, accrualstatus, acno, dayspastdue);
			 int br=Integer.parseInt(borrowerrating);
			 int as=Integer.parseInt(accrualstatus);
			 int dpd=Integer.parseInt(dayspastdue);
			 
			 
		 if(defaultstatus.equals("Validate Error") && borrowerrating.equals("0")  && accrualstatus.equals("0") && dayspastdue.equals("0"))
		 {
			 ReDefaulter r=new ReDefaulter(defaultstatus, borrowername, borrowerrating, accrualstatus, acno, dayspastdue);
			 int x=ds.addReDefaulter(r);
			 if(x>0)
			 {
				 int y=ds.deleteDefaulter(acno);
				 if(y>0)
				 {
					 //target="jsp/SendReminder.jsp";
					 target="jsp/UpdateSuccessfully.jsp";
				 }
			 }
		 }
		 else if(defaultstatus.equals("Auto Weaver") && br>0  && as>0 && dpd!=0)
		 { 
			 /*Defaulter d=new Defaulter(defaultstatus, borrowername, borrowerrating, accrualstatus, acno, dayspastdue);
			 int br=Integer.parseInt(borrowerrating);
			 int as=Integer.parseInt(accrualstatus);
			 int dpd=Integer.parseInt(dayspastdue);*/
			/*
			 if(defaultstatus.equals("Auto Weaver") && br>0  && as>0 && dpd!=0)//when to update in defaulter only
			 {*/
				// System.out.println("Inside if of updat dao....");
				 int z=ds.updateDefaulter(d);
				 //System.out.println(z);
				 if(z>0)
				 {
					 //System.out.println("updateing def..   "+z);
					target="jsp/UpdateSuccessfully.jsp";
					 //target="jsp/SendReminder.jsp";
				 }	 
			// }
			
		else
		 {
			 int x=ds.addDefaulter(d);
			 //System.out.println(x);
			 if(x>0)
			 {
				 int y=ds.deleteReDefaulter(acno);
				 //System.out.println("Adding def..   "+y);
				 if(y>0)
				 {
					 //target="jsp/SendReminder.jsp";
					 target="jsp/UpdateSuccessfully.jsp";
				 }	
			 }
			 
		 }
			
		}
		}
	// }
		 catch (Exception e) {
				e.printStackTrace();
		 }	
	 }
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Navigating to 6 months list in display it..............	 
	 
	 if(act.equals("Users with DPD above 6 months"))
	 {
		 //System.out.println("Above 6 months");
			try {
				ArrayList<Defaulter> al=ds.listDPD6months();
				hsn.setAttribute("Above6months", al);
				target="jsp/6 months.jsp";
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	 }
 /*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Navigating to Send Reminder Page..............	 	 
	 
	 if(act.equals("Navigate"))
	 {
		 String ac=request.getParameter("Account_Number");
		 BigDecimal acno=new BigDecimal(ac);
		 hsn.setAttribute("sendremacno", acno);
		 target="jsp/SendReminder.jsp";
	 }
	 
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Send Reminder to User..............
		 if(act.equals("Send"))
		 {
			 //System.out.println("After send action");
			 String reminder=request.getParameter("reminder");
			 String ac=request.getParameter("acno");
			 BigDecimal acno=new BigDecimal(ac);
			 try {
				int x=ds.sendReminder(reminder, acno);
				//System.out.println(x);
				if(x>0)
				{
					//System.out.println("Reminder send successfully......");
					ArrayList<UserData> al=ds.listUserData();
					Date remDate=new Date(); 
					Reminder r=new Reminder(acno,remDate,reminder);
					int y=ds.addReminder(r);
					//System.out.println(y);
					if(y>0)
					{
					target="jsp/SendReminderSuccess.jsp";
					}
				}
				
			}
			 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Show list of those users to which reminder has been send 
		 if(act.equals("ShowUsers"))
		 {
			// System.out.println("All User");
			 BigDecimal acno=(BigDecimal) hsn.getAttribute("sendremacno");
				try {
					ArrayList<UserData> al=ds.listUserData();
					hsn.setAttribute("userslist", al);
					target="jsp/ShowUsers.jsp";
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 }
		 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Send Reminder to User..............
		 if(act.equals("home"))
		 {
			 target="jsp/home.jsp";
		 }
		 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
	 //insert into Userdata table(User Registration)
	 
	 if(act.equals("User Register"))
	 {
		// System.out.println("Action user insert");
		 String userfname=request.getParameter("userfname");
		 String userlname=request.getParameter("userlname");
		 long usercontact=Long.parseLong(request.getParameter("usercontact"));
		 BigDecimal acno=new BigDecimal(request.getParameter("useraccount"));
		 
		 hsn.setAttribute("fname", userfname);
		 hsn.setAttribute("lname", userlname);
		 hsn.setAttribute("useracno", acno);
		 
		 String userid=request.getParameter("userid");
		 String password=request.getParameter("password");
		 
		 UserData ud= new UserData(userfname, userlname, usercontact, acno, userid, password);
		 try {
			 
			int x=ds.addUserData(ud);
			if(x>0)
			{
				//System.out.println("User reg successfully......");
				target="jsp/LoanDetails.jsp";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 
	 }
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//Get Last Date of loan on LoanDetails.jsp page
	 if(act.equals("Get Last Date"))
	 {
		 try {
			// SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-");
			 long loanamt=Long.parseLong(request.getParameter("loanamt"));
			 String loandate=request.getParameter("loandate");
			 Date ldate=sdf.parse(loandate);
			 long duration=Long.parseLong(request.getParameter("duration"));
			 
			 int dur=(int) duration;
			 Calendar c=Calendar.getInstance();
			 c.setTime(ldate);
			 c.add(Calendar.DAY_OF_MONTH,dur);
			 String lastdate=sdf.format(c.getTime());
			 
			 hsn.setAttribute("loanamt", loanamt);
			 hsn.setAttribute("loandate",loandate );
			 hsn.setAttribute("duration", duration);
			 hsn.setAttribute("lastdate", lastdate);
			 target="jsp/LoanDetails.jsp";
			 
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 }
	 
	 
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/	
//insert into Userdata table(User Registration)
	 if(act.equals("Submit Details"))
	 {
		 try {
		// System.out.println("Action loan insert");
		 BigDecimal accno=(BigDecimal) hsn.getAttribute("useracno");
		 long loanamt=Long.parseLong(request.getParameter("loanamt"));
		 
		 String loandate=request.getParameter("loandate");
		 Date ldate=sdf.parse(loandate);
		 
		 long duration=Long.parseLong(request.getParameter("duration"));
		 hsn.setAttribute("loanamt", loanamt);
		 
		 String lastdate=request.getParameter("lastdate");
		 Date lastd=sdf.parse(lastdate);
		 Loan l=new Loan(accno, loanamt, ldate, duration, lastd);
		 
		 //Getting defaulter data from reg form...

		 String fname=(String) hsn.getAttribute("fname");
		 String lname=(String) hsn.getAttribute("lname");
		 String borrowername=fname+" "+lname;
		 BigDecimal acno=(BigDecimal) hsn.getAttribute("useracno");
		 
		 ReDefaulter d=new  ReDefaulter("Validate Error", borrowername, "0", "0", acno, "0");
		 int  x=ds.addLoan(l);
		 if(x>0)
			{
				//System.out.println("Loan addes successfully......");
				int y=ds.addReDefaulter(d);
				//System.out.println(y);
				if(y>0)
				{
				//System.out.println("Redeaulter added successfully......");
				target="jsp/LoanDetailsSubmitted.jsp";
				}
			}
		
		}
		 catch (Exception e) {
			e.printStackTrace();
		}
		 
	 }
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
//Change password link
	 if(act.equals("ChangePass"))
	 {
		 target="jsp/ChangePassword.jsp";
	 }
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
//Change Password functionality
	if(act.equals("Reset"))
	{
		String uid=(String) hsn.getAttribute("Userid");
		String oldpsw=request.getParameter("pwd");
		String psw=request.getParameter("npwd");
		//System.out.println("inside Reset Action.......!!");
		
		
		Admin ad=(Admin) hsn.getAttribute("AdminObject");
		UserData ud=(UserData) hsn.getAttribute("UserObject");
		
		//System.out.println(ad);
		//System.out.println(ud);
		
		try {
			int x=0,y=0;	
		if(ad!=null)
		{
			 if(ad.getPassword().equals(oldpsw))
			{	
				//System.out.println(ad.getPassword());
					x=ds.changeAP(uid, psw);
					if(x>0)
					{
						//System.out.println("Admin pass change successfully.......!!");
						target="jsp/PasswordChanged.jsp";
					}
			}
			 else
			{
					hsn.setAttribute("Cp", "true");
					target="jsp/ChangePassword.jsp";
			}
		}
		else if(ud!=null)
			{
				if(ud.getPassword().equals(oldpsw))
				{
					//System.out.println(ud.getPassword());
					y=ds.changeUP(uid, psw);
					if(y>0)
					{
						//System.out.println("User pass change successfully.......!!");
						target="jsp/PasswordChanged.jsp";
					}
				}
				else
				{
					hsn.setAttribute("Cp", "true");
					target="jsp/ChangePassword.jsp";
				}
			}
	/*else
		{
			hsn.setAttribute("Cp", "true");
			target="jsp/ChangePassword.jsp";
		}*/
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
//get Data from Loan Table to.. 
	 if(act.equals("PayLoan"))
	 {
		 UserData u=(UserData) hsn.getAttribute("UserObject");
		 try {
			 Loan l =ds.getLoanData(u.getAccno());
			hsn.setAttribute("PayLoanObj", l);
			//System.out.println(l);
			 target="jsp/PayLoan.jsp";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	 }
/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
// Insert and update the pending and paid amount in Loan Table..........
	 if(act.equals("Pay"))
	 {
		// System.out.println("Inside action...");
		 String pendingamt=request.getParameter("pendingamt");
		 long pending=Long.parseLong(pendingamt);
		 
		 String payamt=request.getParameter("payamt");
		 long pay=Long.parseLong(payamt);
		 
		 String loanamt=request.getParameter("loanamt");
		 long amount=Long.parseLong(loanamt);
		 
		 String loandate=request.getParameter("loandate");
		 
		 String duration=request.getParameter("duration");
		 long dur=Long.parseLong(duration);
		 
		 String lastdate=request.getParameter("lastdate");
		 BigDecimal acno=(BigDecimal) hsn.getAttribute("accountofuser");
		 
		 pending=pending-pay;
		 
		 try {
			 	request.setAttribute("UpdatedPendingAmt", pending);
			 	Loan l=new Loan(acno,pending, amount, sdf.parse(loandate), dur, sdf.parse(lastdate));
			 	l.setPaidAmt(pay);
			 	int x=ds.payLoan(l);
			 	//System.out.println(x);
			 	if(x>0)
			 	{
			 		//System.out.println("Loan amount paid..");
			 		Date tdate=new Date();
			 		Transaction t=new Transaction(acno, amount, pay, pending,tdate);	 		
			 		ds.addTransaction(t);
			 		
			 		Date takenLoandate=sdf.parse(loandate);
			 		Date takenLastdate=sdf.parse(lastdate);
			 		
//System.out.println("Loan Date "+takenLoandate);
//System.out.println("Last Date "+takenLastdate);
			 		Calendar c=Calendar.getInstance();
			 		c.setTime(takenLastdate);
			 		c.add(Calendar.DAY_OF_MONTH,90);
					String temp=sdf.format(c.getTime());
//System.out.println("Transaction date "+tdate);					
					Date tempDate=sdf.parse(temp);
//System.out.println("Temp Date "+tempDate);		 		
					 long difference = tdate.getTime()-takenLastdate.getTime();
				       long DPD = (difference / (1000*60*60*24));	
				       
//System.out.println("Days Past Due "+DPD);	
					
					int y=ds.updateDPD(acno, DPD);
					//System.out.println(y);
					if(y>0)
					{
			 		target="jsp/Invoice.jsp";
					}
					target="jsp/Invoice.jsp";
					
			 	}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }

/*&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
//Display loan transactions done by user..... 
	 if(act.equals("Transaction"))
	 {
			//System.out.println("Transaction List");
			try {
				UserData ud=(UserData) hsn.getAttribute("UserObject");
				ArrayList<Transaction> al=ds.listAllTransactions(ud.getAccno());
				hsn.setAttribute("TransactionList", al);
				//System.out.println(al);
				 target="jsp/Transactions.jsp";
			
			} catch (Exception e) {
				e.printStackTrace();
			}
	 }


//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&*/		 
//Update Defaulter table........ 
	 
	 if(act.equals("Notification"))
	 {
		UserData ud=(UserData) hsn.getAttribute("UserObject");
		 //System.out.println("Reminder receive");
		 try {
			ArrayList<Reminder> rem=ds.receiveReminder(ud.getAccno());
			//System.out.println(rem);
			hsn.setAttribute("receiveRem", rem);
			
			target="jsp/Notification.jsp";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 }
	 
	 
	    //System.out.println("request dispaciter");
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	 
		pw.close();
	
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
