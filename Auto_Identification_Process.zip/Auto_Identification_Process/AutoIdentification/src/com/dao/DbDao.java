package com.dao;


import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.Icommands.IAdmin;
import com.Icommands.ILoan;
import com.beans.Admin;
import com.beans.Defaulter;
import com.beans.Loan;
import com.beans.ReDefaulter;
import com.beans.Reminder;
import com.beans.Transaction;
import com.beans.UserData;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
import com.util.DbUtil;

public class DbDao implements IAdmin,ILoan
{
//#################################################--ADMIN--#####################################################
	
//---------------------------------------------------------------------------------------------------------------
//Getting Name of Admin using userId(Email id) to store in session....
	public Admin getUname(String userid) throws SQLException {
		Connection con=DbUtil.getConnection();
		Admin ad=new Admin();
		String name=null;
		PreparedStatement psmt=con.prepareStatement(getUserName);
		psmt.setString(1,userid);
		ResultSet rs=psmt.executeQuery();
		if(rs.next())
		{
			 name=rs.getString(1);
			 String lname=rs.getString(2);
			 int age=rs.getInt(3);
			 String gen=rs.getString(4);
			 String cn=rs.getString(5);
			 String city=rs.getString(6);
			 String state=rs.getString(7);
			 String uid=rs.getString(8);
			 String pwd=rs.getString(9);
			 ad=new Admin(name, lname, age, gen, cn, city, state, uid, pwd);
		}
		//ad.setFirst_Name(name);
		psmt.close();
		rs.close();
		con.close();
		return ad;	
	}
	
	
//---------------------------------------------------------------------------------------------------------------
//Adding data to admindata table........

	public int addAdmin(Admin ad) throws SQLException {
		
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(inscmd);
		psmt.setString(1,ad.getFirst_Name());
		psmt.setString(2, ad.getLast_Name());
		psmt.setInt(3, ad.getAge());
		psmt.setString(4, ad.getGender());
		//psmt.setInt(5, ad.getContact_no());
		psmt.setString(5, ad.getContact_no());
		psmt.setString(6, ad.getCity());
		psmt.setString(7, ad.getState());
		psmt.setString(8, ad.getUserId());
		psmt.setString(9, ad.getPassword());
		int x=psmt.executeUpdate();
		psmt.close();
		con.close();
		return x;
		
	}
	
//---------------------------------------------------------------------------------------------------------------
//Change admin password...
	public int changeAP(String uname,String psw) throws SQLException {
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(changeAPass);
		psmt.setString(1,psw );
		psmt.setString(2, uname);
		int x=psmt.executeUpdate();
		psmt.close();
		con.close();
		return x;
	}

	
//---------------------------------------------------------------------------------------------------------------
//Adding data to defaulter table....
	public int addDefaulter(Defaulter d) throws SQLException {
		Connection con=DbUtil.getConnection();
		//System.out.println("inside dao add defaulter...");
		PreparedStatement psmt=con.prepareStatement(insertdefaulter);
		psmt.setString(1,d.getDefaultStatus());
		psmt.setString(2,d.getBorrowerName());
		psmt.setString(3,d.getBorrowerRating());
		psmt.setString(4,d.getAcuralStatus());
		psmt.setBigDecimal(5, d.getAccountNumber());
		psmt.setString(6, d.getDaysPastDue());
		int x=psmt.executeUpdate();
		psmt.close();
		con.close();
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Adding data to Redefaulter table....
		public int addReDefaulter(ReDefaulter d) throws SQLException {
			Connection con=DbUtil.getConnection();
			//System.out.println("inside dao add redefaulter.......");
			PreparedStatement psmt=con.prepareStatement(insertRedefaulter);
			psmt.setString(1,d.getDefaultStatus());
			psmt.setString(2,d.getBorrowerName());
			psmt.setString(3,d.getBorrowerRating());
			psmt.setString(4,d.getAcuralStatus());
			psmt.setBigDecimal(5, d.getAccountNumber());
			psmt.setString(6, d.getDaysPastDue());
			int x=psmt.executeUpdate();
			psmt.close();
			con.close();
			return x;
		}
//---------------------------------------------------------------------------------------------------------------
//Deleting data from defaulter table...
		public int deleteDefaulter(BigDecimal acno) throws SQLException {
			Connection con=DbUtil.getConnection();
			//System.out.println("inside dao delete  defaulter ....");
			PreparedStatement psmt=con.prepareStatement(deleteDefaulter);
			psmt.setBigDecimal(1,acno);
			int x=psmt.executeUpdate();
			psmt.close();
			con.close();
			return x;
		}

//---------------------------------------------------------------------------------------------------------------
//Deleting data from Redefaulter table...
		public int deleteReDefaulter(BigDecimal acno) throws SQLException {
			Connection con=DbUtil.getConnection();
			//System.out.println("inside dao redefaulter delete ....");
			PreparedStatement psmt=con.prepareStatement(deleteRedefaulter);
			psmt.setBigDecimal(1,acno);
			int x=psmt.executeUpdate();
			psmt.close();
			con.close();
			return x;
		}

		
//---------------------------------------------------------------------------------------------------------------
//Select admin credentials from admindata table............
	public boolean getAdminCred(String uname,String psw) throws SQLException {
			
		boolean flag=false;
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(logincmd);
		psmt.setString(1,uname);
		psmt.setString(2, psw);
		ResultSet rs=psmt.executeQuery();
		if(rs.next())
		{
			flag=true;
		}
		psmt.close();
		rs.close();
		con.close();
		return flag;
	}

		
//---------------------------------------------------------------------------------------------------------------	
//Select list of all Defaulters............
	public ArrayList<Defaulter> listAllDefaulters() throws SQLException
	{
		try
		{
		ArrayList<Defaulter> al=new ArrayList<Defaulter>();
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(selectdefaulter);
		psmt.setString(1, "Auto Weaver");
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			String defaultStatus=rs.getString(1);
			String borrowername=rs.getString(2);
			String borroerrating=rs.getString(3);
			String accuralstatus=rs.getString(4);
			//long acno=rs.getInt(5);
			BigDecimal acno=rs.getBigDecimal(5);
			String dayspastdue=rs.getString(6);
			
			Defaulter de=new  Defaulter(defaultStatus, borrowername, borroerrating, accuralstatus, acno, dayspastdue);
			al.add(de);
		}
		psmt.close();
		rs.close();
		con.close();
		return al;
	}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	
	}

//---------------------------------------------------------------------------------------------------------------	
//Select list of ReDefaulters............

	public ArrayList<ReDefaulter> listAllReDefaulters() throws SQLException {
		try
		{
			//System.out.println("inside dao re defaulter list ");
		ArrayList<ReDefaulter> al=new ArrayList<ReDefaulter>();
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(selectRedefaulter);
		psmt.setString(1, "Validate Error");
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			String defaultStatus=rs.getString(1);
			String borrowername=rs.getString(2);
			String borroerrating=rs.getString(3);
			String accuralstatus=rs.getString(4);
			//long acno=rs.getInt(5);
			BigDecimal acno=rs.getBigDecimal(5);
			String dayspastdue=rs.getString(6);
			
			ReDefaulter de=new  ReDefaulter(defaultStatus, borrowername, borroerrating, accuralstatus, acno, dayspastdue);
			al.add(de);
		}
		psmt.close();
		rs.close();
		con.close();
		return al;
	}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}


	
	
//---------------------------------------------------------------------------------------------------------------
//Select list of auto Defaulters............ 
	public ArrayList<Defaulter> listAutoDefaulters() throws SQLException
	{
		try
		{
		ArrayList<Defaulter> al=new ArrayList<Defaulter>();
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(autodefaulter);
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			String defaultStatus=rs.getString(1);
			String borrowername=rs.getString(2);
			String borroerrating=rs.getString(3);
			String accuralstatus=rs.getString(4);
			//long acno=rs.getInt(5);
			BigDecimal acno=rs.getBigDecimal(5);
			String dayspastdue=rs.getString(6);
			
			Defaulter de=new  Defaulter(defaultStatus, borrowername, borroerrating, accuralstatus, acno, dayspastdue);
			al.add(de);
		}
		psmt.close();
		rs.close();
		con.close();
		return al;
	}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	
//---------------------------------------------------------------------------------------------------------------
//Select list of Manual Defaulters............ 
	public ArrayList<Defaulter> listManualDefaulters() throws SQLException {
		// TODO Auto-generated method stub
		try
		{
		ArrayList<Defaulter> al=new ArrayList<Defaulter>();
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(manualdefaulter);
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			String defaultStatus=rs.getString(1);
			String borrowername=rs.getString(2);
			String borroerrating=rs.getString(3);
			String accuralstatus=rs.getString(4);
			//long acno=rs.getInt(5);
			BigDecimal acno=rs.getBigDecimal(5);
			String dayspastdue=rs.getString(6);
			
			Defaulter de=new  Defaulter(defaultStatus, borrowername, borroerrating, accuralstatus, acno, dayspastdue);
			al.add(de);
		}
		psmt.close();
		rs.close();
		con.close();
		return al;
	}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	
//---------------------------------------------------------------------------------------------------------------
//Select list of Defaulters having DPD >= 6 months............ 
	public ArrayList<Defaulter> listDPD6months() throws SQLException {
		try
		{
			//System.out.println("inside dao 6 months defaulter list ");
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(DPD6month);
		ArrayList<Defaulter> al=new ArrayList<Defaulter>();
		ResultSet rs=psmt.executeQuery();
		while(rs.next())
		{
			String defaultStatus=rs.getString(1);
			String borrowername=rs.getString(2);
			String borroerrating=rs.getString(3);
			String accuralstatus=rs.getString(4);
			//long acno=rs.getInt(5);
			BigDecimal acno=rs.getBigDecimal(5);
			String dayspastdue=rs.getString(6);
			
			Defaulter de=new  Defaulter(defaultStatus, borrowername, borroerrating, accuralstatus, acno, dayspastdue);
			al.add(de);
		}
		psmt.close();
		rs.close();
		con.close();
		return al;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	
//---------------------------------------------------------------------------------------------------------------
//Updating defaulter data in defaulter table..............
	public int updateDefaulter(Defaulter d) throws SQLException {
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(updatedefaulter);
		psmt.setString(1, d.getDefaultStatus());
		psmt.setString(2,d.getBorrowerRating());
		psmt.setString(3,d.getAcuralStatus());
		psmt.setString(4,d.getDaysPastDue());
		psmt.setBigDecimal(5, d.getAccountNumber());
		int x=psmt.executeUpdate();
		//System.out.println("Inside update dao");
		psmt.close();
		con.close();
		return x;
	}

	
//---------------------------------------------------------------------------------------------------------------
//Updating Days Past Due in defaulter table..............

	public int updateDPD(BigDecimal acno, long dpd) throws SQLException {
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(updateDPD);
		psmt.setLong(1,dpd);
		psmt.setBigDecimal(2, acno);
		int x=psmt.executeUpdate();
		//System.out.println("inside update dpd dao send");
		psmt.close();
		con.close();
		return x;
	}

	

//---------------------------------------------------------------------------------------------------------------
//insert reminder into UserData table..............
		public int sendReminder(String rem,BigDecimal acno) throws SQLException {
			Connection con=DbUtil.getConnection();
			//UserData ud=new UserData();
			PreparedStatement psmt=con.prepareStatement(sendReminder);
			psmt.setString(1,rem);
			psmt.setBigDecimal(2, acno);
			int x=psmt.executeUpdate();
			//System.out.println("inside dao send");
			psmt.close();
			con.close();
			return x;
		}
		
//---------------------------------------------------------------------------------------------------------------
//select reminder from UserData table..............
		public ArrayList<Reminder> receiveReminder(BigDecimal acno) throws SQLException {
			Connection con=DbUtil.getConnection();
			//System.out.println("inside dao of get rem");
			ArrayList<Reminder> al=new ArrayList<Reminder>();
			PreparedStatement psmt=con.prepareStatement(receiveReminder);
			psmt.setBigDecimal(1, acno);
			ResultSet rs=psmt.executeQuery();
			while(rs.next())
			{
				BigDecimal accno=rs.getBigDecimal(1);
				java.sql.Date rd=rs.getDate(2);
				
				Date remDate=new Date(rd.getTime());
				String rem=rs.getString(3);
				
				Reminder r=new Reminder(accno, remDate, rem);
				al.add(r);
			}
			psmt.close();
			rs.close();
			con.close();
			return al;
		}
		
		
//---------------------------------------------------------------------------------------------------------------
//Add user data of those Users to which reminder has been sent.......
		public ArrayList<UserData> listUserData() throws SQLException {
			Connection con=DbUtil.getConnection();
			ArrayList<UserData> al=new ArrayList<UserData>();
			PreparedStatement psmt=con.prepareStatement(selectUser);
		//	psmt.setBigDecimal(1, accno);
			ResultSet rs=psmt.executeQuery();
			while(rs.next())
			{
				String fname=rs.getString(1);
				String lname=rs.getString(2);
				BigDecimal acno=rs.getBigDecimal(3);
				String rem=rs.getString(4);
				
				UserData ud=new UserData(fname, lname, acno, rem);
				al.add(ud);
			}
			psmt.close();
			rs.close();
			con.close();
			return al;
		}

		
		
		
		
		
		
		
		

//#################################################--USER--######################################################
	
//---------------------------------------------------------------------------------------------------------------
//Getting Name of user using userId(Email id) to store in session....
		public UserData getUserName(String email) throws SQLException {
			// TODO Auto-generated method stub
			UserData ud=new UserData();
			String name=null;
			String pwd=null;
			Connection con=DbUtil.getConnection();
			PreparedStatement psmt=con.prepareStatement(getUserN);
			psmt.setString(1,email);
			ResultSet rs=psmt.executeQuery();
			if(rs.next())
			{
				 String fname=rs.getString(1);
				 String lname=rs.getString(2);
				 long cn=rs.getLong(3);
				 BigDecimal acno=rs.getBigDecimal(4);
				 pwd=rs.getString(6);
				 System.out.println(pwd);
				 ud=new UserData(fname, lname, cn, acno, email,pwd);

			}
			psmt.close();
			rs.close();
			con.close();
			return ud;
			
		}
	
		
//---------------------------------------------------------------------------------------------------------------
//inserting data in UserData table..............
	public int addUserData(UserData ud) throws SQLException {
		//System.out.println("inside dao user");
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(insertUser);
		psmt.setString(1, ud.getFname());
		psmt.setString(2, ud.getLname());
		psmt.setLong(3, ud.getContact());
		psmt.setBigDecimal(4, ud.getAccno());
		psmt.setString(5, ud.getEmail());
		psmt.setString(6, ud.getPassword());
		int x=psmt.executeUpdate();
		//System.out.println("exiting dao user");
		psmt.close();
		con.close();
		return x;
	}

//---------------------------------------------------------------------------------------------------------------
//Select user credentials from UserData table............
    public boolean getUserCred(String uname,String psw) throws SQLException
		{
		boolean flag=false;
		Connection con=DbUtil.getConnection();
		PreparedStatement psmt=con.prepareStatement(loginUser);
		psmt.setString(1,uname);
		psmt.setString(2, psw);
		ResultSet rs=psmt.executeQuery();
		if(rs.next())
		{
			flag=true;
		}
		psmt.close();
		rs.close();
		con.close();
		return flag;
	}
    
  //---------------------------------------------------------------------------------------------------------------
  //Change User password...
  		public int changeUP(String uname,String psw) throws SQLException {
  			Connection con=DbUtil.getConnection();
  			PreparedStatement psmt=con.prepareStatement(changeUPass);
  			psmt.setString(1,psw );
  			psmt.setString(2,uname);
  			int x=psmt.executeUpdate();
  			psmt.close();
			con.close();
  			return x;
  		}
    
//---------------------------------------------------------------------------------------------------------------
//inserting data in LoanData table..............
	public int addLoan(Loan l) throws SQLException {
		Connection con=DbUtil.getConnection();
		//System.out.println("inside dao loan");
		PreparedStatement psmt=con.prepareStatement(insertLoan);
		psmt.setBigDecimal(1, l.getAcno());
		psmt.setLong(2,l.getAmount());
		
		java.sql.Date ldate=new java.sql.Date(l.getLoanDate().getTime());
		psmt.setDate(3, ldate);
		
		psmt.setLong(4,l.getDuration());
		
		java.sql.Date lastdate=new java.sql.Date(l.getLastDate().getTime());
		psmt.setDate(5, lastdate);
		int x=psmt.executeUpdate();
		//System.out.println("exit dao loan");
		psmt.close();
		con.close();
		return x;
	}

//---------------------------------------------------------------------------------------------------------------
//selecting data from LoanData table..............
public Loan getLoanData(BigDecimal acno) throws SQLException, ParseException {
	Connection con=DbUtil.getConnection();
	PreparedStatement psmt=con.prepareStatement(Loandata);
	psmt.setBigDecimal(1, acno);
	ArrayList<Loan> al=new ArrayList<Loan>();
	ResultSet rs=psmt.executeQuery();
	Loan l=new Loan();
	while(rs.next())
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Long pending=rs.getLong(1);
		Long lamt=rs.getLong(2);
		java.sql.Date loandate=rs.getDate(3);
		Date d= new Date(loandate.getTime());
		Long duration=rs.getLong(4);
		
		java.sql.Date ldate=rs.getDate(5);
		Date d1= new Date(ldate.getTime());
		if(pending==0)
		{
			l=new Loan(acno,lamt, lamt, d,duration,d1);
		}
		else if(pending<0)
		{
			l=new Loan(acno,0, lamt, d,duration,d1);
		}
		else 
		{
			l=new Loan(acno,pending, lamt, d,duration,d1);
		}
	}	
	psmt.close();
	rs.close();
	con.close();
	return l;
}

//---------------------------------------------------------------------------------------------------------------
//Updating payment details into LoanData table..............
public int payLoan(Loan l) throws SQLException {
	Connection con=DbUtil.getConnection();
	//System.out.println("inside dao.......");
	PreparedStatement psmt=con.prepareStatement(payment);
	psmt.setLong(1,l.getPendingAmt());
	psmt.setLong(2,l.getPaidAmt());
	psmt.setBigDecimal(3,l.getAcno());
	int x=psmt.executeUpdate();
	psmt.close();
	con.close();
	return x;
}

//---------------------------------------------------------------------------------------------------------------
//Adding transaction details in Transaction table..............
public int addTransaction(Transaction t) throws SQLException {
	Connection con=DbUtil.getConnection();
	//System.out.println("inside transaction dao.......");
	PreparedStatement psmt=con.prepareStatement(transaction);
	psmt.setBigDecimal(1, t.getAccount_Number());
	psmt.setLong(2, t.getLoan_Amount());
	psmt.setLong(3, t.getPaid());
	psmt.setLong(4, t.getPending_Amount());
	
	java.sql.Date tdate=new java.sql.Date(t.getDate().getTime());
	psmt.setDate(5, tdate);
	
	int x=psmt.executeUpdate();
	psmt.close();
	return x;
}


//---------------------------------------------------------------------------------------------------------------
//Selecting transaction details from Transaction table..............
public ArrayList<Transaction> listAllTransactions(BigDecimal acno) throws SQLException, ParseException {
	Connection con=DbUtil.getConnection();
	SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	ArrayList<Transaction> al=new ArrayList<Transaction>();
	PreparedStatement psmt=con.prepareStatement(listAllTransactions);

	psmt.setBigDecimal(1, acno);
	ResultSet rs=psmt.executeQuery();
	while(rs.next())
	{
		BigDecimal accno=rs.getBigDecimal(1);
		long loanAmt=rs.getLong(2);
		long paid=rs.getLong(3);
		long pending=rs.getLong(4);
		
		java.sql.Date currdate=rs.getDate(5);
		Date tdate= new Date(currdate.getTime());
	
		Transaction t1=new Transaction(accno, loanAmt, paid, pending,tdate);
		al.add(t1);
	}
	psmt.close();
	rs.close();
	con.close();
	return al;
}

//---------------------------------------------------------------------------------------------------------------
//inserting Reminder into reminder table..............
public int addReminder(Reminder r) throws SQLException {
	Connection con=DbUtil.getConnection();
	//System.out.println("Inside rem dao..");
	PreparedStatement psmt=con.prepareStatement(insertRem);
	psmt.setBigDecimal(1, r.getAcno());
	java.sql.Date remDate =new java.sql.Date( r.getRemDate().getTime());
	psmt.setDate(2,remDate);
	psmt.setString(3, r.getRem());
	int x=psmt.executeUpdate();
	psmt.close();
	con.close();
	return x;
}


//---------------------------------------------------------------------------------------------------------------
//getting account number.........
public ArrayList<BigDecimal> getAccNo() throws SQLException {
	Connection con=DbUtil.getConnection();
	PreparedStatement psmt=con.prepareStatement(getAccNo);
	ResultSet rs=psmt.executeQuery();
	ArrayList<BigDecimal> al= new ArrayList<BigDecimal>();
	while(rs.next())
	{
		BigDecimal accno=rs.getBigDecimal(1);
		al.add(accno);
	}
	return al;
}





}
