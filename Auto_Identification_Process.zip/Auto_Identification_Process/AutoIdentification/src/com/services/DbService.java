package com.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import com.Icommands.IAdmin;
import com.Icommands.ILoan;
import com.beans.Admin;
import com.beans.Defaulter;
import com.beans.Loan;
import com.beans.ReDefaulter;
import com.beans.Reminder;
import com.beans.Transaction;
import com.beans.UserData;
import com.dao.DbDao;

public class DbService implements IAdmin,ILoan 
{

	DbDao dao=new DbDao();

	//---------------------------------------------------------------------------------------------------------------
	//Adding data to admindata table........
	public int addAdmin(Admin ad) throws SQLException {
		int x=dao.addAdmin(ad);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Adding data to defaulter table
	public int addDefaulter(Defaulter d) throws SQLException {
		int x=dao.addDefaulter(d);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Adding data to Redefaulter table
	public int addReDefaulter(ReDefaulter d) throws SQLException {
		int x=dao.addReDefaulter(d);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Deleting data from defaulter table...
	public int deleteDefaulter(BigDecimal acno) throws SQLException {
		int x=dao.deleteDefaulter(acno);
		return x;
	}
	//---------------------------------------------------------------------------------------------------------------
	//Deleting data from Redefaulter table...
	public int deleteReDefaulter(BigDecimal acno) throws SQLException {
		int x=dao.deleteReDefaulter(acno);
		return x;
	}
	
	
	//---------------------------------------------------------------------------------------------------------------
	//Getting Name of Admin using userId(Email id) to store in session....
	public Admin getUname(String userid) throws SQLException {
		Admin ad=dao.getUname(userid);
		return ad;
	}
	
	//---------------------------------------------------------------------------------------------------------------
		//Getting Name of user using userId(Email id) to store in session....
	public UserData getUserName(String email) throws SQLException {
		UserData ud=dao.getUserName(email);
		return ud;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Select admin credentials from admindata table............
	public boolean getAdminCred(String uname,String psw) throws SQLException {
		boolean flag=false;
		flag=dao.getAdminCred(uname, psw);
		return flag;
		
	}
	
	
//---------------------------------------------------------------------------------------------------------------
//Select user credentials from UserData table............
	public boolean getUserCred(String uname,String psw) throws SQLException
	{
		boolean flag=false;
		flag=dao.getUserCred(uname, psw);
		return flag;
	}
	
	//---------------------------------------------------------------------------------------------------------------	
	//Select list of all Defaulters............
	public ArrayList<Defaulter> listAllDefaulters() throws SQLException {
		ArrayList<Defaulter> al=dao.listAllDefaulters();
		return al;
	}
	
	
	//---------------------------------------------------------------------------------------------------------------	
	//Select list of all ReDefaulters............
	public ArrayList<ReDefaulter> listAllReDefaulters() throws SQLException {
		ArrayList<ReDefaulter> al=dao.listAllReDefaulters();
		return al;
	}

	
	//---------------------------------------------------------------------------------------------------------------
	//Select list of auto Defaulters............ 
	public ArrayList<Defaulter> listAutoDefaulters() throws SQLException
	{
		ArrayList<Defaulter> al=dao.listAutoDefaulters();
		return al;
	}

	
	//---------------------------------------------------------------------------------------------------------------
	//Select list of Manual Defaulters............ 
	public ArrayList<Defaulter> listManualDefaulters() throws SQLException
	{
		ArrayList<Defaulter> al=dao.listManualDefaulters();
		return al;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Select list of Defaulters having DPD >= 6 months............ 
	public ArrayList<Defaulter> listDPD6months() throws SQLException {
		ArrayList<Defaulter> al=dao.listDPD6months();
		return al;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Updating defaulter data in defaulter table..............
	public int updateDefaulter(Defaulter d) throws SQLException {
		int x=dao.updateDefaulter(d);
		return x;
	}

	//---------------------------------------------------------------------------------------------------------------
	//Updating Days Past Due in redefaulter table..............
		public int updateDPD(BigDecimal acno, long dpd) throws SQLException {
			int x=dao.updateDPD(acno, dpd);
			return x;
		}
		

	//---------------------------------------------------------------------------------------------------------------
	//inserting data in UserData table..............
	public int addUserData(UserData ud) throws SQLException {
		int x=dao.addUserData(ud);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//inserting data in LoanData table..............
	public int addLoan(Loan l) throws SQLException {
		int x=dao.addLoan(l);
		return x;
	
	}

	//---------------------------------------------------------------------------------------------------------------
	//insert reminder into table..............
	public int sendReminder(String rem,BigDecimal acno) throws SQLException {
		int x=dao.sendReminder(rem, acno);
		return x;
		
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Selecting all reminders from Reminder table..............
	public ArrayList<Reminder> receiveReminder(BigDecimal acno) throws SQLException {
		ArrayList<Reminder> al=dao.receiveReminder(acno);
		return al;
	}

	//---------------------------------------------------------------------------------------------------------------
	//change user password ..............
	public int changeUP(String uname, String psw) throws SQLException {
		int x=dao.changeUP(uname, psw);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//change Admin password ..............
	public int changeAP(String uname, String psw) throws SQLException {
		int x=dao.changeAP(uname, psw);
		return x;
	}

	//---------------------------------------------------------------------------------------------------------------
	//getting user data.....
	public ArrayList<UserData> listUserData() throws SQLException {
		ArrayList<UserData> al=dao.listUserData();
		return al;
	}

	//---------------------------------------------------------------------------------------------------------------
	//selecting data from LoanData table..............
	public Loan getLoanData(BigDecimal acno) throws SQLException, ParseException {
		Loan al=dao.getLoanData(acno);
		return al;
	}

	//---------------------------------------------------------------------------------------------------------------
	//Updating payment details into LoanData table..............
	public int payLoan(Loan l) throws SQLException {
		int x=dao.payLoan(l);
		return x;
	}
	
	//---------------------------------------------------------------------------------------------------------------
	//Adding transaction details in Transaction table..............
	public int addTransaction(Transaction t) throws SQLException {
		int x=dao.addTransaction(t);
		return x;
	}

	//---------------------------------------------------------------------------------------------------------------
	//Selecting transaction details from Transaction table..............
	public ArrayList<Transaction> listAllTransactions(BigDecimal acno) throws SQLException, ParseException {
		ArrayList<Transaction> al=dao.listAllTransactions(acno);
		return al;
	}

	//---------------------------------------------------------------------------------------------------------------
	//Selecting Reminder from reminder table..............
	public int addReminder(Reminder r) throws SQLException {
		int x=dao.addReminder(r);
		return x;
	}

	public ArrayList<BigDecimal> getAccNo() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	
	

	

	
	

	

	
	
	
	

	

}
